java -Dsun.security.smartcardio.library=libpcsclite.so.1 -jar eid-toolset-gui-1.0-SNAPSHOT.jar
