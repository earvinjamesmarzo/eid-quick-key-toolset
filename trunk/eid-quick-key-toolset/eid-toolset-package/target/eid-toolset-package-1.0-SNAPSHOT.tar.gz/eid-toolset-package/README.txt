README for the FedICT eID Quick-Key Toolset
==================================

=== 1. Introduction

Run the tool via:
	java -jar eid-toolset-gui-1.0-SNAPSHOT.jar


=== 2. License

The license conditions for the eID TSL artifacts can be found in the 
file: LICENSE.txt
The license conditions for the third party software included as a part in
this product can be found in the file: 3RD-PARTY-LICENSE.txt

